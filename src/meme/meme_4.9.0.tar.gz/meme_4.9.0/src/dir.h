#define MEME_DIR "/home/james"
#define ETC_DIR "/home/james/etc" 
#define BIN_DIR "/home/james/bin" 
