#!@WHICHPERL@
# Author: Timothy Bailey
# Modified: Philip Machanick (for ChIP-seq)
##
##

use strict;
use warnings;

use lib qw(@PERLLIBDIR@);

use CGI qw(:standard);
use File::Basename qw(fileparse);
use MIME::Base64;
use Scalar::Util qw(looks_like_number);
use SOAP::Lite;

use Globals;
use OpalServices;
use OpalTypes;
use MemeWebUtils qw(get_safe_name get_safe_file_name loggable_date);


# Setup logging
my $logger = undef;
eval {
  require Log::Log4perl;
  Log::Log4perl->import();
};
unless ($@) {
  Log::Log4perl::init('@APPCONFIGDIR@/logging.conf');
  $logger = Log::Log4perl->get_logger('meme.cgi.memechip');
  $SIG{__DIE__} = sub {
    return if ($^S);
    $logger->fatal(@_);
    die @_;
  };
}
$logger->trace("Starting meme-chip CGI") if $logger;

# setup constants
$CGI::POST_MAX = 1024 * 1024 * 55; # Limit post to 55MB
$CGI::DISABLE_UPLOADS = 0; # Allow file uploads
my $PROGRAM = "MEMECHIP";
my $BIN_DIR = "@MEME_DIR@/bin";
my $SERVICE_URL = "@OPAL@/MEMECHIP_@S_VERSION@";
my $HELP_EMAIL = '@contact@';


&process_request();
exit(0);

sub process_request {
  $logger->trace("call process_request") if $logger;
  my $q = CGI->new;
  my $utils = new MemeWebUtils($PROGRAM, $BIN_DIR);
  
  unless (defined $q->param('target_action')) { # display the form
    &display_form($utils, $q);
  } else { # try to submit to the webservice
    my $data = &check_parameters($utils, $q);
    if (!$utils->has_errors()) {
      &submit_to_opal($utils, $q, $data);
    } else {
      $utils->print_tailers();
    }
  }
}

#
# display the form
#
sub display_form {
  $logger->trace("call display_form") if $logger;
  my ($utils, $q) = @_;

  #open the template
  #my $template = HTML::Template->new(filename => 'dreme.tmpl');

  #fill in parameters
  #$template->param(version => $VERSION);
  #$template->param(help_email => $HELP_EMAIL);

  if (!$utils->has_errors()) { # output the html
    print $q->header, &make_form($utils, $q);
  } else { # finish off the errors
    $utils->print_tailers();
  }
}

#
# print the form
#
sub make_form {
  $logger->trace("call make_form") if $logger;
  my ($utils, $q) = @_;

  my $action = "meme-chip.cgi";
  my $logo = "../doc/images/memechip_logo.png";
  my $alt = "$PROGRAM logo";
  my $form_description = qq {
This version of $PROGRAM is designed especially for discovering <A
HREF="../meme-intro.html"><B>motifs</B></A>
in <b>LARGE</b> sets of DNA sequences such as those produced by ChIP-seq
experiments. <b>There is a 50MB upper limit.</b> This corresponds to a maximum 
of approximately 100,000 sequences of length 500bp.
A motif is a description of a common pattern in sequences,
such as a transcription factor binding site.  Use this form to submit DNA
sequences to $PROGRAM and a number of other tools that aid in finding motifs
and evaluating the quality of the found motifs.
For more information about MEME-ChIP,
<span style="color:red; font-weight: bold">see this <a
href="../doc/meme-chip-tutorial.html">Tutorial</a></span>.
  }; # end quote

  #
  # required left side: address and sequences fields
  #
  my $seq_doc = "../help_sequences.html#sequences";
  my $alpha_doc = "../help_alphabet.html";
  my $format_doc = "../help_format.html";
  my $filename_doc = "../help_sequences.html#filename";
  my $paste_doc = "../help_sequences.html#actual-sequences";
  my $sample_file = "../examples/sample-dna-Klf1.fa";
  my $sample_alphabet = "DNA";
  my $req_left = $utils->make_address_field();
  $req_left .= $utils->make_upload_sequences_field("datafile", "data", undef,
    $seq_doc, $alpha_doc, $format_doc, $filename_doc, $paste_doc, $sample_file,
    $sample_alphabet);

  #
  # required right side
  #

  # make distribution buttons
  my $distr_doc = "../meme-input.html#distribution";
  my $distr = "How do you think the occurrences of a single motif are <A HREF='$distr_doc'><B>distributed</B></A> among the DNA sequences?\n<BR>\n";
  my $checked = "zoops";
  my @values = (
    "<B>One per sequence</B>\n<BR>,oops", 
    "<B>Zero or one</B> per sequence\n<BR>,zoops",
    "<B>Any number</B> of repetitions\n<BR>,anr"
  );
  my $req_right = $utils->make_radio_field($distr, "dist", $checked, \@values);

  # make width fields
  $req_right .= qq {
<BR>
<!-- width fields -->
<BR>
MEME will find the optimum <A HREF="../help_width.html#motif_width"><B>width</B></A> 
of each motif within the limits you specify here: 
<BR>
<INPUT CLASS="maininput" TYPE="TEXT" SIZE=3 NAME="minw" VALUE=6>
<B>Minimum</B> width (>= $MINW)
<BR>
<INPUT CLASS="maininput" TYPE="TEXT" SIZE=3 NAME="maxw" VALUE=$DEFAULTMAXW>
<B><A HREF="../help_width.html#max_width">Maximum</B></A> width (<= $MAXW)
<BR>
<BR>
<INPUT CLASS="maininput" TYPE="TEXT" SIZE=2 NAME="nmotifs" VALUE=3>
Maximum <A HREF="../meme-input.html#nmotifs"><B>number of motifs</B></A>
to find
  }; # end quote

  # finish required fields
  my $required = $utils->make_input_table("Required", $req_left, $req_right);

  #
  # optional fields
  #

  # optional left: description, nsites, shuffle fields 
  my $descr = "DNA sequences";
  my $opt_left = $utils->make_description_field($descr);

  # make nsites fields
  $opt_left .= qq {
<BR>
<!-- nsites fields -->
<BR>
MEME will find the optimum 
<A HREF="../meme-input.html#nsites"><B>number of sites</B></A>
for each motif within the limits you specify here: 
<BR>
<INPUT CLASS="maininput" TYPE="TEXT" SIZE=3 NAME="minsites" VALUE="">
<B>Minimum</B> sites (>= $MINSITES)
<BR>
<INPUT CLASS="maininput" TYPE="TEXT" SIZE=3 NAME="maxsites" VALUE="">
<B>Maximum</B> sites (<= $MAXSITES)
<BR>
<BR>
  }; # end quote

  my $opt_right .= qq {
Enter the name of a file containing a 
<A HREF="../meme-input.html#bfile"><B>background Markov model</B></A>:
<BR>
<div id="upload_bfile_div">
  <input class="maininput" name="upload_bfile" type="file" size=18>
  <a onclick="clearFileInputField('upload_bfile_div')" href="javascript:noAction();"><b>Clear</b></a>
</div>
  }; # end quote

  # DNA-ONLY options (only do DNA here but leave comment in as placeholder in case this changes)
  #if (!defined $alphabet || $alphabet eq "ACGT") 
  {
    my ($doc, $text, $options);
    $doc = "../meme-input.html#posonly";
    $text = "Search given <A HREF='$doc' <B>strand</B></A> only";
    $options = $utils->make_checkbox("posonly", "1", $text, 0); 
    $options .= "<BR>\n";
    $doc = "../meme-input.html#pal";
    $text = "Look for <A HREF='$doc'><B>palindromes</B></A> only";
    $options .= $utils->make_checkbox("pal", "1", $text, 0); 
    $options .= "<br>\n";
    $doc = "../mast-intro.html";
    $text = "Run <a href='$doc'><b>MAST</b></a>";
    $options .= $utils->make_checkbox("run_mast", "1", $text, 0); 
    $options .= "<br>\n";
    $doc = "../doc/ama.html";
    $text = "Run <a href='$doc'><b>AMA</b></a>";
    $options .= $utils->make_checkbox("run_ama", "1", $text, 0); 
    $opt_right .= $options;
  } # dna options

  # last 1 turns on showhide
  my $showhide = 1;
  my $optional = $utils->make_input_table("Options", $opt_left, $opt_right); 

  #
  # make final form
  #
  my $form = $utils->make_submission_form(
    $utils->make_form_header($PROGRAM, "Submission form"),
    $utils->make_submission_form_top($action, $logo, $alt, $form_description),
    $required, 
    $optional , #. $advanced, 
    $utils->make_submit_button("Start search", $HELP_EMAIL),
    $utils->make_submission_form_bottom(),
    $utils->make_submission_form_tailer()
  );
  return $form;
  
} # make_form

#
# check the parameters and whine if any are bad
#
sub check_parameters {
  $logger->trace("call check_parameters") if $logger;
  my ($utils, $q) = @_;
  my %d = ();
  my $alpha;

  # get the input sequences
  ($d{SEQS_DATA}, $alpha, $d{SEQS_COUNT}, $d{SEQS_MIN}, 
    $d{SEQS_MAX}, $d{SEQS_AVG}, $d{SEQS_TOTAL}) = 
  $utils->get_sequence_data($q->param('data'), $q->param('datafile'));
  # get the input sequences name
  $d{SEQS_ORIG_NAME} = ($q->param('data') ? 'sequences' : fileparse($q->param('datafile')));
  $d{SEQS_NAME} = get_safe_name($d{SEQS_ORIG_NAME}, 'sequences', 2);

  # get the motif distribution mode
  $d{MODE} = $utils->param_choice($q, 'dist', 'oops', 'zoops', 'anr');

  # get the motif width bounds
  $d{MINW} = $utils->param_int($q, 'minw', 'minimum width', $MINW, $MAXW, 6);
  $d{MAXW} = $utils->param_int($q, 'maxw', 'maximum width', $MINW, $MAXW, 50);
  if ($d{MINW} > $d{MAXW}) {
    $utils->whine("The minimum width (" . $d{MINW} . ") must be less than ".
      "or equal to the maximum width (" . $d{MAXW} . ").");
  }

  # get the motif count bound
  $d{NMOTIFS} = $utils->param_int($q, 'nmotifs', 'maximum motifs', 1, undef, 3);

  # get the optional description
  $d{DESCRIPTION} = $utils->param_require($q, 'description');

  # check for optional site bounds
  $d{MINSITES} = $utils->param_int($q, 'minsites', 'minimum sites', $MINSITES, $MAXSITES);
  $d{MAXSITES} = $utils->param_int($q, 'maxsites', 'maximum sites', $MINSITES, $MAXSITES);
  if (defined($d{MINSITES}) && defined($d{MAXSITES}) && $d{MINSITES} > $d{MAXSITES}) {
    $utils->whine("The minimum sites (" . $d{MINSITES} . ") must be less than ".
      "or equal to the maximum sites (" . $d{MAXSITES} . ").");
  }

  # check for optional background Markov model
  if ($q->param('upload_bfile')) {
    my $file = $q->upload('upload_bfile');
    $d{BFILE_DATA} = do {local $/; <$file>};
    $d{BFILE_DATA} =~ s/\r\n/\n/g; # Windows -> UNIX eol
    $d{BFILE_DATA} =~ s/\r/\n/g; # MacOS -> UNIX eol
    $d{BFILE_NAME} = get_safe_file_name(
      $q->param('upload_bfile'), 'uploaded_bfile', 2);
  }

  # check for options
  $d{POSONLY} = $utils->param_bool($q, 'posonly');
  $d{PAL} = $utils->param_bool($q, 'pal');
  $d{RUN_MAST} = $utils->param_bool($q, 'run_mast');
  $d{RUN_AMA} = $utils->param_bool($q, 'run_ama');

  # get the email
  $d{EMAIL} = $utils->param_email($q);
  
  # set alpha
  $d{ALPHA} = lc($alpha);

  return \%d;
}

#
# make the arguments list
#
sub make_arguments {
  $logger->trace("call make_arguments") if $logger;
  my ($data) = @_;
  my @databases = ("JASPAR_CORE_2009.meme");
  my @args = ();

  push(@args, '-run-mast') if ($data->{RUN_MAST});
  push(@args, '-run-ama') if ($data->{RUN_AMA});
  push(@args, '-bfile', $data->{BFILE_NAME}) if (defined($data->{BFILE_NAME}));
  # meme options
  push(@args, '-meme-mod', $data->{MODE}) if (defined($data->{MODE}));
  push(@args, '-meme-minw', $data->{MINW}) if (defined($data->{MINW}));
  push(@args, '-meme-maxw', $data->{MAXW}) if (defined($data->{MAXW}));
  push(@args, '-meme-nmotifs', $data->{NMOTIFS}) if (defined($data->{NMOTIFS}));
  push(@args, '-meme-minsites', $data->{MINSITES}) if (defined($data->{MINSITES}));
  push(@args, '-meme-maxsites', $data->{MAXSITES}) if (defined($data->{MAXSITES}));
  push(@args, '-meme-norevcomp') if ($data->{POSONLY});
  push(@args, '-meme-pal') if ($data->{PAL});
  push(@args, $data->{SEQS_NAME}, @databases);

  $logger->info(join(' ', @args)) if $logger;
  return @args;
}

#
# make the verification message in HTML
#
sub make_verification {
  $logger->trace("call make_verification") if $logger;
  my ($data) = @_;

  my %motif_occur = (zoops => 'Zero or one per sequence', 
    oops => 'One per sequence', anr => 'Any number of repetitions');

  #open the template
  my $template = HTML::Template->new(filename => 'meme-chip_verify.tmpl');

  #fill in parameters
  $template->param(description => $data->{DESCRIPTION});
  $template->param(motif_occur => $motif_occur{$data->{MODE}});
  $template->param(nmotifs => $data->{NMOTIFS});
  $template->param(minsites => $data->{MINSITES});
  $template->param(maxsites => $data->{MAXSITES});
  $template->param(minw => $data->{MINW});
  $template->param(maxw => $data->{MAXW});
  $template->param(posonly => $data->{POSONLY});
  $template->param(pal => $data->{PAL});
  $template->param(bfile_name => $data->{BFILE_NAME});

  $template->param(run_mast => $data->{RUN_MAST});
  $template->param(run_ama => $data->{RUN_AMA});

  $template->param(seqs_name => $data->{SEQS_NAME});
  $template->param(seqs_count => $data->{SEQS_COUNT});
  $template->param(seqs_min => $data->{SEQS_MIN});
  $template->param(seqs_max => $data->{SEQS_MAX});
  $template->param(seqs_avg => $data->{SEQS_AVG});
  $template->param(seqs_total => $data->{SEQS_TOTAL});

  return $template->output;
}

#
# Submit job to webservice via OPAL
#
sub submit_to_opal
{
  $logger->trace("call submit_to_opal") if $logger;
  my ($utils, $q, $data) = @_;

  # make the verification form and email message
  my $verify = &make_verification($data);

  my $service = OpalServices->new(service_url => $SERVICE_URL);

  # start OPAL requst
  my $req = JobInputType->new();
  $req->setArgs(join(' ', &make_arguments($data)));

  # create list of OPAL file objects
  my @infilelist = ();
  # Sequence file
  push(@infilelist, InputFileType->new($data->{SEQS_NAME}, $data->{SEQS_DATA}));
  # Background file
  if ($data->{BFILE_NAME}) {
    push(@infilelist, InputFileType->new($data->{BFILE_NAME}, $data->{BFILE_DATA}));
  }
  # Description file
  if ($data->{DESCRIPTION} =~ m/\S/) {
    push(@infilelist, InputFileType->new("description", $data->{DESCRIPTION}));
  }
  # Email address file (for logging purposes only)
  push(@infilelist, InputFileType->new("address_file", $data->{EMAIL}));
  # Submit time file (for logging purposes only)
  push(@infilelist, InputFileType->new("submit_time_file", loggable_date()));

  # Add file objects to request
  $req->setInputFile(@infilelist);

  # Submit the request to OPAL
  my $result = $service->launchJob($req);

  # Give user the verification form and email message
  print $q->header;
  $utils->verify_opal_job($result, $data->{EMAIL}, $HELP_EMAIL, $verify);

} # submit_to_opal
