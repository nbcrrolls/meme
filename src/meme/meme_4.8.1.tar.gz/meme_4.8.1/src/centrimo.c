/********************************************************************
 * FILE: centrimo.c
 * AUTHOR: Timothy Bailey, Philip Machanick
 * CREATE DATE: 06/06/2011
 * PROJECT: MEME suite
 * COPYRIGHT: 2011, UQ
 ********************************************************************/

#define DEFINE_GLOBALS
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <libgen.h> // for basename
#include "matrix.h"
#include "alphabet.h"
#include "binomial.h"
#include "config.h"
#include "dir.h"
#include "fasta-io.h"
#include "hash_alph.h"
#include "html-monolith.h"
#include "io.h"
#include "motif-in.h"
#include "projrel.h"
#include "pssm.h"
#include "seq-reader-from-fasta.h"
#include "simple-getopt.h"
#include "string-list.h"
#include "utils.h"
#include "background.h"
#include "seq.h"

#include <sys/resource.h>
#include <unistd.h>

const double DEFAULT_PSEUDOCOUNT = 0.1;
const double DEFAULT_SCORE_THRESH = 5.0;
const double DEFAULT_EVALUE_THRESH = 10.0;
const int DEFAULT_MAX_WINDOW = -1;
const double ALPHA = 1.0; // Non-motif specific scale factor.
const char* TEMPLATE_FILENAME = "centrimo_template.html";
const char* SITES_FILENAME = "site_counts.txt";// Name of plain-text sites
const char* TEXT_FILENAME = "centrimo.txt";// Name of plain-text centrimo output
const char* HTML_FILENAME = "centrimo.html";// Name of HTML centrimo output
const char* CENTRIMO_USAGE =
  "USAGE: centrimo [options] <sequence file> <motif file>+\n"
  "\n"
  "   Options:\n"
  "     --o <output dir>         output directory; default: 'centrimo_out'\n"
  "     --oc <output dir>        allow overwriting; default: 'centrimo_out'\n"
  "     --bgfile <background>    background frequency model for PWMs;\n"
  "                               default: base frequencies in input sequences\n"
  "     --motif <ID>             only scan with this motif; options may be\n"
  "                               repeated to specify more than one motif;\n"
  "                               default: scan with all motifs\n"
  "     --motif-pseudo <pseudo>  pseudo-count to use creating PWMs;\n"
  "                               default: %.3g\n"
  "     --score <S>              score threshold for PWMs, in bits;\n"
  "                               sequences without a site with score >= <S>\n"
  "                               are ignored; default: %.1g\n"
  "     --ethresh <thresh>       evalue threshold for including in results;\n"
  "                               default: %g\n"
  "     --maxbin <width>         maximum width of the central region (bin) to\n"
  "                               consider; default: use the sequence length\n"
  "     --norc                   do not scan with the reverse complement motif\n"
  "     --noflip                 do not 'flip' the sequence; use rc of motif instead;\n"
  "                               default: rc matches appear 'reflected' around center\n"
  "     --desc <description>     include the description in the output;\n"
  "                               default: no description\n"
  "     --dfile <desc file>      use the file content as the description;\n"
  "                               default: no description\n"
  "     --verbosity [1|2|3|4]    verbosity of output: 1 (quiet) - 4 (dump);\n"
  "                               default: %d\n"
  "\n";

VERBOSE_T verbosity = NORMAL_VERBOSE;
// output a message provided the verbosity is set appropriately
#define DEBUG_MSG(debug_level, debug_msg) { \
  if (verbosity >= debug_level) { \
    fprintf(stderr, debug_msg); \
  } \
}

#define DEBUG_FMT(debug_level, debug_msg_format, ...) { \
  if (verbosity >= debug_level) { \
    fprintf(stderr, debug_msg_format, __VA_ARGS__); \
  } \
}

// Structure for tracking centrimo command line parameters.
typedef struct options {
  ALPH_T alphabet;              // Alphabet (DNA only for the moment)

  BOOLEAN_T allow_clobber;      // Allow overwritting of files in output directory.
  BOOLEAN_T scan_both_strands;  // Scan forward and reverse strands.
  BOOLEAN_T no_flip;		// Do not flip sequence when scoring RC motif.

  RBTREE_T *selected_motifs;    // IDs of requested motifs.

  char* description;            // description of job
  char* desc_file;              // file containing description
  char* bg_source;              // Name of file file containg background freq.
  char* output_dirname;         // Name of the output directory
  char* seq_source;             // Name of file containg sequences.
  ARRAYLST_T* motif_sources;    // Names of files containing motifs.

  double score_thresh;          // Minimum value of site score (bits).

  double pseudocount;           // Pseudocount added to motif PSPM.

  double evalue_thresh;         // Don't report results with worse evalue
  double log_evalue_thresh;     // Log of evalue threshold

  int max_window;               // Maximum considered central window size
} CENTRIMO_OPTIONS_T;

typedef struct motif_db {
  int id;
  char* source;
  ARRAYLST_T* motifs;
} MOTIF_DB_T;

typedef struct site {
  int start;
  char strand;
} SEQ_SITE_T;

typedef struct sites {
  double best;
  int allocated;
  int used;
  SEQ_SITE_T *sites;
} SEQ_SITES_T;

typedef struct counts {
  long total_sites;
  int allocated;
  double *sites; // there are ((2 * seqlen) - 1) sites
} SITE_COUNTS_T;

typedef struct stats {
  MOTIF_DB_T* db;
  MOTIF_T* motif;
  long total_sites;
  double max_prob;
  int all_window; // window that contains all bins
  double central_sites;
  int central_window;
  double central_prob;
  double log_pvalue;
  int n_win_tested;
  double log_adj_pvalue;
} MOTIF_STATS_T;

#define SCORE_BLOCK 20

/*************************************************************************
 * Compare two motif_stats in an arraylst
 * Takes pointers to pointers to MOTIF_STATS_T.
 *************************************************************************/
static int motif_stats_compar(const void *s1, const void *s2) {
  MOTIF_STATS_T *m_stats1, *m_stats2;
  double diff;
  int diff2;
  m_stats1 = *((MOTIF_STATS_T**)s1);
  m_stats2 = *((MOTIF_STATS_T**)s2);
  diff = m_stats1->log_adj_pvalue - m_stats2->log_adj_pvalue;
  if (diff != 0) return (diff < 0 ? -1 : 1);
  diff2 = strcmp(get_motif_id(m_stats1->motif), get_motif_id(m_stats2->motif));
  if (diff2 != 0) return diff2;
  return m_stats1->db->id - m_stats2->db->id;
}

/***********************************************************************
  Free memory allocated in options processing
 ***********************************************************************/
static void cleanup_options(CENTRIMO_OPTIONS_T *options) {
  rbtree_destroy(options->selected_motifs);
}

/***********************************************************************
  Process command line options
 ***********************************************************************/
static void process_command_line(
  int argc,
  char* argv[],
  CENTRIMO_OPTIONS_T *options
) {

  // Define command line options.
  const int num_options = 12;
  cmdoption const centrimo_options[] = {
    {"bgfile", REQUIRED_VALUE},
    {"o", REQUIRED_VALUE},
    {"oc", REQUIRED_VALUE},
    {"score", REQUIRED_VALUE},
    {"motif-pseudo", REQUIRED_VALUE},
    {"ethresh", REQUIRED_VALUE},
    {"maxbin", REQUIRED_VALUE},
    {"norc", NO_VALUE},
    {"noflip", NO_VALUE},
    {"desc", REQUIRED_VALUE},
    {"dfile", REQUIRED_VALUE},
    {"verbosity", REQUIRED_VALUE}
  };


  int option_index = 0;

  /* Make sure various options are set to NULL or defaults. */
  options->alphabet = DNA_ALPH;
  options->allow_clobber = TRUE;
  options->scan_both_strands = TRUE;
  options->no_flip = FALSE;

  options->description = NULL;
  options->desc_file = NULL;
  options->bg_source = NULL;
  options->output_dirname = "centrimo_out";
  options->seq_source = NULL;
  options->motif_sources = arraylst_create();

  options->score_thresh = DEFAULT_SCORE_THRESH;

  options->pseudocount = DEFAULT_PSEUDOCOUNT;

  options->evalue_thresh = DEFAULT_EVALUE_THRESH;

  options->max_window = DEFAULT_MAX_WINDOW;

  // no need to copy, as string is declared in argv array
  options->selected_motifs = rbtree_create(rbtree_strcmp, NULL, NULL, NULL, NULL);

  verbosity = NORMAL_VERBOSE;

  simple_setopt(argc, argv, num_options, centrimo_options);

  // Parse the command line.
  while (TRUE) {
    int c = 0;
    char* option_name = NULL;
    char* option_value = NULL;
    const char * message = NULL;

    // Read the next option, and break if we're done.
    c = simple_getopt(&option_name, &option_value, &option_index);
    if (c == 0) {
      break;
    }
    else if (c < 0) {
      (void) simple_getopterror(&message);
      fprintf(stderr, "Error processing command line options (%s)\n", message);
      fprintf(stderr, CENTRIMO_USAGE, DEFAULT_PSEUDOCOUNT, DEFAULT_SCORE_THRESH,
          DEFAULT_EVALUE_THRESH, NORMAL_VERBOSE);
      exit(EXIT_FAILURE);
    }
    if (strcmp(option_name, "bgfile") == 0){
      options->bg_source = option_value;
    }
    else if (strcmp(option_name, "ethresh") == 0){
      options->evalue_thresh = atof(option_value);
    }
    else if (strcmp(option_name, "maxbin") == 0){
      // max_window is one less than the number of places a motif can align
      // within the central window
      options->max_window = atoi(option_value) - 1;  
    }
    else if (strcmp(option_name, "motif") == 0){
      rbtree_put(options->selected_motifs, option_value, NULL);
    }
    else if (strcmp(option_name, "motif-pseudo") == 0){
      options->pseudocount = atof(option_value);
    }
    else if (strcmp(option_name, "norc") == 0){
      options->scan_both_strands = FALSE;
    }
    else if (strcmp(option_name, "noflip") == 0){
      options->no_flip = TRUE;
    }
    else if (strcmp(option_name, "o") == 0){
      // Set output directory with no clobber
      options->output_dirname = option_value;
      options->allow_clobber = FALSE;
    }
    else if (strcmp(option_name, "oc") == 0){
      // Set output directory with clobber
      options->output_dirname = option_value;
      options->allow_clobber = TRUE;
    }
    else if (strcmp(option_name, "score") == 0){
      options->score_thresh = atof(option_value);
    }
    else if (strcmp(option_name, "desc") == 0) {
      options->description = option_value;
    } 
    else if (strcmp(option_name, "dfile") == 0) {
      options->desc_file = option_value;
    }
    else if (strcmp(option_name, "verbosity") == 0){
      verbosity = atoi(option_value);
    }
  }
  // Must have sequence and motif file names
  if (argc < option_index + 2) {
      fprintf(stderr, "Sequences and motifs are both required\n");
    fprintf(stderr, CENTRIMO_USAGE, DEFAULT_PSEUDOCOUNT, DEFAULT_SCORE_THRESH,
        DEFAULT_EVALUE_THRESH, NORMAL_VERBOSE);
    exit(EXIT_FAILURE);
  }

  // Record the input file names
  options->seq_source = argv[option_index++];
  for (;option_index < argc; option_index++) 
    arraylst_add(argv[option_index], options->motif_sources);

  // Set up path values for needed stylesheets and output files.
}

/*************************************************************************
 * Calculate the log odds score for a single motif-sized window.
 *************************************************************************/
static inline BOOLEAN_T score_motif_site(
  ALPH_T alph,
  char *seq,
  PSSM_T *pssm,
  double *score // OUT
) {
  int asize = alph_size(alph, ALPH_SIZE);
  MATRIX_T* pssm_matrix = pssm->matrix;
  double scaled_log_odds = 0.0;

  // For each position in the site
  int motif_position;
  for (motif_position = 0; motif_position < pssm->w; motif_position++) {

    char c = seq[motif_position];
    int aindex = alph_index(alph, c);
    // Check for gaps and ambiguity codes at this site
    if(aindex == -1 || aindex >= asize) return FALSE;

    scaled_log_odds += get_matrix_cell(motif_position, aindex, pssm_matrix);
  }

  *score = get_unscaled_pssm_score(scaled_log_odds, pssm);

  // Handle scores that are out of range
  if ((int) scaled_log_odds >= get_array_length(pssm->pv)) {
    scaled_log_odds = (float)(get_array_length(pssm->pv) - 1);
    *score = scaled_to_raw(scaled_log_odds, pssm->w, pssm->scale, pssm->offset);
  }
  return TRUE;
}

/*************************************************************************
 * Keep track of any sites which have the best score seen
 *************************************************************************/
static void track_site(SEQ_SITES_T* seq_sites, double score, 
    int start, char strand) {
  SEQ_SITE_T *site;
  // don't bother recording worse scores
  if (score < seq_sites->best) return;
  // better scores clear the list
  if (score > seq_sites->best) {
    seq_sites->used = 0;
    seq_sites->best = score;
  }
  // allocate memory on demand
  if (seq_sites->allocated <= seq_sites->used) {
    seq_sites->allocated += SCORE_BLOCK;
    mm_resize(seq_sites->sites, seq_sites->allocated, SEQ_SITE_T);
  }
  // store the site
  site = seq_sites->sites+(seq_sites->used++);
  site->start = start;
  site->strand = strand;
}

/*************************************************************************
 * Calculate the log-odds score for each possible motif site in the 
 * sequence and record the sites of the best. Apply a count to each
 * best site and increment the total site count.
 *************************************************************************/
static void score_sequence(
  CENTRIMO_OPTIONS_T *options,
  SEQ_T* sequence,
  PSSM_T*  pssm,
  PSSM_T*  rev_pssm,
  SEQ_SITES_T* seq_sites,
  SITE_COUNTS_T* counts
)
{
  char *raw_seq, *seg;
  int i, L, w, pos;
  double score;
  double count;
  SEQ_SITE_T *site;
  // check we got passed stuff
  assert(options != NULL);
  assert(sequence != NULL);
  assert(pssm != NULL);
  assert(seq_sites != NULL);
  assert(counts != NULL);
  // make Mac OS compiler happy.
  score = -BIG;
  // Score and record each possible motif site in the sequence
  raw_seq = get_raw_sequence(sequence);
  L = get_seq_length(sequence);
  w = pssm->w;
  // Reset the sequence stats structure
  seq_sites->best = -BIG;
  seq_sites->used = 0;
  // Read and score each position in the sequence.
  for (i = 0; i < L - w + 1; i++) {
    seg = raw_seq+i;
    // Score and record forward strand
    if (score_motif_site(options->alphabet, seg, pssm, &score)) 
      track_site(seq_sites, score, i, '+');
    // Score and record reverse strand if appropriate.
    if (rev_pssm && score_motif_site(options->alphabet, seg, rev_pssm, &score)) 
      track_site(seq_sites, score, i, '-');
  }
  // Record the position of best site, averaging ties
  // and using position in RC of sequence if site on reverse strand
  // unless no_flip is true.
  if (seq_sites->used && seq_sites->best >= options->score_thresh) {
    // add 1/n_ties to each tied position's count, 
    // averaging rather than random choice 
    count = (double)1.0 / (double)seq_sites->used;
    for (i = 0; i < seq_sites->used; i++) {
      site = seq_sites->sites+i;
      if (options->no_flip || site->strand == '+') {
        //pos = 2 * (site->start + w/2 - 1/2); // a motif of width 1 can have sites at the first index
        pos = 2 * site->start + w - 1; // a motif of width 1 can have sites at the first index
      } else {
        //pos = 2 * (L - (site->start + w/2) - 1; // a motif of width 1 can have sites at the first index
        pos = 2 * (L - site->start) - w - 1;
      }
      //record the count
      counts->sites[pos] += count;
    }
    counts->total_sites++;
  }
}

/*************************************************************************
 * Compute the enrichment of a central window
 *************************************************************************/
static double window_enrichment(int window, 
    double window_sites, long total_sites, 
    int bins, int max_bins) {
  // p-value vars
  double log_p_value;
  // calculate the log p-value
  if (window_sites == 0 || bins == max_bins) {
    log_p_value = 0; // pvalue of 1
  } else {
    double n_trials, n_successes, p_success;
    n_trials = (double)total_sites;
    n_successes = window_sites;
    p_success = (double)bins / (double)max_bins;
    log_p_value = log_betai(n_successes, n_trials - n_successes + 1.0, p_success);
    DEBUG_FMT(DUMP_VERBOSE, "window: %4d p_success: %20.15e "
        "successes: %10.4f trials: %5.0f = log_p-value: %10.5e\n", window, 
        p_success, n_successes, n_trials, log_p_value);
  }
  return log_p_value;
}

/*************************************************************************
 * Compute the enrichment of the central region
 *************************************************************************/
static MOTIF_STATS_T* compute_stats(int max_window, int sequence_length, 
    MOTIF_DB_T* db, MOTIF_T* motif, SITE_COUNTS_T* counts) {
  // variables
  MOTIF_STATS_T *stats;
  double window_counts, max_sites;
  int i, max_bins, is_centered, big_window, middle, window, bins;
  double log_p_value;
  // allocate memory for stats
  stats = mm_malloc(sizeof(MOTIF_STATS_T));
  // initilise stats to defaults
  stats->db = db;
  stats->motif = motif;
  stats->total_sites = counts->total_sites;
  stats->n_win_tested = 0;
  stats->max_prob = 0;
  stats->central_sites = 0;
  stats->central_prob = 0.0;
  stats->central_window = 0;
  stats->log_pvalue = 0;
  stats->log_adj_pvalue = 0;
  // find the largest site count
  max_sites = 0;
  for (i = 0; i < counts->allocated; i++) {
    if (max_sites < counts->sites[i]) max_sites = counts->sites[i];
  }
  // calculate the max probability
  stats->max_prob = (counts->total_sites == 0 ? 0 : 
      max_sites / (double)counts->total_sites);
  // get the number of bins that the motif could possibly have landed in
  max_bins = sequence_length - get_motif_length(motif) + 1;
  // determine if this motif can have sites in a completely central bin
  is_centered = (max_bins % 2);
  // calculate the window that contains all sites from this motif
  stats->all_window = max_bins - is_centered;
  // calculate the biggest window which might have a p-value
  big_window = stats->all_window - 2;
  // check that max window is ok
  if (max_window == -1 || max_window > big_window) max_window = big_window;
  if (max_window < 0) return stats; // no windows to test!
  // calculate the number of tested windows
  stats->n_win_tested = (is_centered ? (max_window / 2) + 1 : (max_window + 1) / 2);
  if (stats->n_win_tested == 0) return stats; // no windows to test!
  // the index of the bin in the center
  middle = sequence_length - 1;
  // initialise counts
  stats->log_pvalue = BIG; //ensure it is replaced by the loop
  window_counts = 0;
  bins = 0;
  if (is_centered) { // test the central window
    bins++;
    window_counts  = counts->sites[middle];
    stats->log_pvalue = window_enrichment(0, 
        window_counts, counts->total_sites, bins, max_bins);
    stats->central_sites = window_counts;
    stats->central_prob = (double)bins / (double)max_bins;
  }
  // find the best window by trying all possible windows
  for (bins += 2, window = bins-1; window <= max_window; bins += 2, window += 2) {
    window_counts +=  counts->sites[middle - window];
    window_counts += counts->sites[middle + window];
    // calculate the window p-value
    log_p_value = window_enrichment(window, 
        window_counts, counts->total_sites, bins, max_bins);
    // check if the p-value is better
    if (log_p_value < stats->log_pvalue) {
      stats->log_pvalue = log_p_value;
      stats->central_window = window;
      stats->central_sites = window_counts;
      stats->central_prob = (double)bins / (double)max_bins;
    }
  }
  stats->log_adj_pvalue = LOGEV(log(stats->n_win_tested), stats->log_pvalue);
  DEBUG_FMT(HIGHER_VERBOSE, "best bin: %d sites: %g "
      "log_adj_p-value: %g (%d tests)\n", stats->central_window+1, 
      stats->central_sites, stats->log_adj_pvalue, 
      stats->n_win_tested);
  return stats;
}


/*************************************************************************
 * Output motif site counts
 *************************************************************************/
static void output_site_counts(FILE* fh, int sequence_length, 
    MOTIF_DB_T* db, MOTIF_T* motif, SITE_COUNTS_T* counts) {
  // vars
  int i, w, end;
  char *alt;
  fprintf(fh, "DB %d MOTIF\t%s", db->id, get_motif_id(motif));
  alt = get_motif_id2(motif);
  if (alt[0]) fprintf(fh, "\t%s", alt);
  fprintf(fh, "\n");
  w = get_motif_length(motif);
  end = counts->allocated - (w - 1);
  for (i = (w - 1); i < end; i += 2) {
    fprintf(fh, "% 6.1f\t%g\n", 
        ((double)(i - sequence_length + 1)) / 2.0, 
        counts->sites[i]);
  }
}

/*************************************************************************
 * Output JSON data for a motif
 *************************************************************************/
static void output_motif_json(JSONWR_T* json, MOTIF_STATS_T* stats, 
    SITE_COUNTS_T* counts) {
  //vars
  MOTIF_T *motif;
  MATRIX_T *freqs;
  int i, j, mlen, asize, end;
  motif = stats->motif;
  freqs = get_motif_freqs(motif);
  asize = alph_size(get_motif_alph(motif), ALPH_SIZE);
  jsonwr_start_object_value(json);
  jsonwr_lng_prop(json, "db", stats->db->id);
  jsonwr_str_prop(json, "id", get_motif_id(motif));
  if (*(get_motif_id2(motif))) {
    jsonwr_str_prop(json, "alt", get_motif_id2(motif));
  }
  mlen = get_motif_length(motif);
  jsonwr_lng_prop(json, "len", mlen);
  jsonwr_dbl_prop(json, "motif_evalue", get_motif_evalue(motif));
  jsonwr_dbl_prop(json, "motif_nsites", get_motif_nsites(motif));
  if (get_motif_url(motif) && *get_motif_url(motif)) {
    jsonwr_str_prop(json, "url", get_motif_url(motif));
  }
  jsonwr_property(json, "pwm");
  jsonwr_start_array_value(json);
  for (i = 0; i < mlen; i++) {
    jsonwr_start_array_value(json);
    for (j = 0; j < asize; j++) {
      jsonwr_dbl_value(json, get_matrix_cell(i, j, freqs));
    }
    jsonwr_end_array_value(json);
  }
  jsonwr_end_array_value(json);
  jsonwr_lng_prop(json, "bin_width", stats->central_window+1);
  jsonwr_dbl_prop(json, "bin_sites", stats->central_sites);
  jsonwr_lng_prop(json, "total_sites", counts->total_sites);
  jsonwr_dbl_prop(json, "log_pvalue", stats->log_adj_pvalue);
  jsonwr_dbl_prop(json, "max_prob", stats->max_prob);
  jsonwr_property(json, "sites");
  jsonwr_start_array_value(json);
  end = counts->allocated - (mlen - 1);
  for (i = (mlen - 1); i < end; i += 2) {
    jsonwr_dbl_value(json, counts->sites[i]);
  }
  jsonwr_end_array_value(json);
  jsonwr_end_object_value(json);
}

/*************************************************************************
 * Output a log value in scientific notation
 *************************************************************************/
static void print_log_value(FILE *file, double loge_val, int prec) {
  double log10_val, e, m;
  log10_val = loge_val / log(10);
  e = floor(log10_val);
  m = pow(10.0, (log10_val - e));
  if ((m + (0.5 * pow(10, -prec))) >= 10) {
    m = 1;
    e += 1;
  }
  fprintf(file, "%.*fe%04.0f", prec, m, e);
}

/*************************************************************************
 * Output CentriMo text output
 *************************************************************************/
static void output_centrimo_text(CENTRIMO_OPTIONS_T *options, int motifN,
    ARRAYLST_T *stats_list) {
  MOTIF_STATS_T *stats;
  char *file_path;
  int i, pad;
  double log_motifN;
  FILE *text_file;
  MOTIF_T *motif;
  // find the evalue conversion factor
  log_motifN = log(motifN);
  // Sort and write centrimo.txt
  arraylst_qsort(motif_stats_compar, stats_list);
  // open centrimo text file
  file_path = make_path_to_file(options->output_dirname, TEXT_FILENAME);
  text_file = fopen(file_path, "w");
  free(file_path);
  fputs("# motif             \tE-value\tadj_p-value\tlog_adj_p-value\t"
      "bin_width\ttotal_width\tsites_in_bin\ttotal_sites\tp_success\t"
      "p-value\tmult_tests\n", text_file);
  fprintf(text_file, "# Found %d motifs with E-values <= %g\n", 
      arraylst_size(stats_list), options->evalue_thresh);
  // write centrimo text output
  for (i = 0; i < arraylst_size(stats_list); i++) {
    stats = arraylst_get(i, stats_list);
    motif = stats->motif;
    pad = 19 - strlen(get_motif_id(motif));
    fprintf(text_file, "%s %-*s\t", get_motif_id(motif), 
        pad, get_motif_id2(motif));
    print_log_value(text_file, stats->log_adj_pvalue + log_motifN, 1);
    fputs("\t", text_file);
    print_log_value(text_file, stats->log_adj_pvalue, 1);
    fprintf(text_file, "\t%.2f\t%d\t%d\t%.0f\t%ld\t%.5f\t", 
        stats->log_adj_pvalue, stats->central_window+1, stats->all_window, 
        stats->central_sites, stats->total_sites, 
        stats->central_prob);
    print_log_value(text_file, stats->log_pvalue, 1);
    fprintf(text_file, "\t%d\n", stats->n_win_tested);
  }
  fclose(text_file);
}

/*************************************************************************
 * Read all the sequences into an array of SEQ_T
 *************************************************************************/
static void read_sequences(ALPH_T alph, char *seq_file_name, 
    SEQ_T ***sequences, int *seq_num) {
  const int max_sequence = 32768; // unlikely to be this big
  int i, seq_len, move;
  FILE * seq_fh = fopen(seq_file_name, "r");
  if (!seq_fh) die("failed to open sequence file `%s'", seq_file_name);
  read_many_fastas(alph, seq_fh, max_sequence, seq_num, sequences);
  if (fclose(seq_fh) != 0) die("failed to close sequence file\n");
  seq_len = get_seq_length((*sequences)[0]);
  move = 0;
  for (i = 1; i < *seq_num; i++) {
    if (seq_len == get_seq_length((*sequences)[i])) {
      if (move > 0) (*sequences)[i-move] = (*sequences)[i];
    } else {
      fprintf(stderr, "Skipping sequence %s as its length (%d) does not "
          "match the first sequence (%d).\n", get_seq_name((*sequences)[i]),
          get_seq_length((*sequences)[i]), seq_len);
      move++;
    }
  }
  *seq_num -= move;
  for (i--; i >= *seq_num; i--) (*sequences)[i] = NULL;
}

/*************************************************************************
 * Read a motif database
 *************************************************************************/
static MOTIF_DB_T* read_motifs(int id, char* motif_source, char* bg_source, 
    ARRAY_T** bg, double pseudocount, RBTREE_T *selected, ALPH_T alph) {
  // vars
  int read_motifs;
  MOTIF_DB_T* motifdb;
  MREAD_T *mread;
  MOTIF_T *motif;
  ARRAYLST_T *motifs;
  // open the motif file for reading
  mread = mread_create(motif_source, OPEN_MFILE);
  mread_set_pseudocount(mread, pseudocount);
  // determine background to use
  if (*bg != NULL) mread_set_background(mread, *bg);
  else mread_set_bg_source(mread, bg_source);
  // load motifs
  read_motifs = 0;
  if (rbtree_size(selected) > 0) {
    motifs = arraylst_create();
    while(mread_has_motif(mread)) {
      motif = mread_next_motif(mread);
      read_motifs++;
      if (rbtree_find(selected, get_motif_id(motif))) {
        arraylst_add(motif, motifs);
      } else {
        DEBUG_FMT(NORMAL_VERBOSE, "Discarding motif %s in %s.\n", 
            get_motif_id(motif), motif_source);
        destroy_motif(motif);
      }
    }
  } else {
    motifs = mread_load(mread, NULL);
    read_motifs = arraylst_size(motifs);
  }
  arraylst_fit(motifs);
  if (read_motifs > 0) {
    // check the alphabet
    if (mread_get_alphabet(mread) != alph) {
      die("Expected %s alphabet motifs\n", alph_name(alph));
    }
    // get the background
    if (*bg == NULL) *bg = mread_get_background(mread);
  } else {
    fprintf(stderr, "Warning: Motif file %s contains no motifs.\n", motif_source);
  }
  // clean up motif reader
  mread_destroy(mread);
  // create motif db
  motifdb = mm_malloc(sizeof(MOTIF_DB_T));
  memset(motifdb, 0, sizeof(MOTIF_DB_T));
  motifdb->id = id;
  motifdb->source = strdup(motif_source);
  motifdb->motifs = motifs;
  return motifdb; 
}

/*************************************************************************
 * If there is no description then return null.
 * If there is a file containing the description then read up to 
 * MAX_JOB_DESC_LEN characters from the file.
 * Convert windows new lines (CRLF) into into line feed. Convert old mac
 * new lines (CR) into line feed. Merge 3 or more contiguous line feeds into
 * two line feeds.
 *************************************************************************/
#define MAX_JOB_DESC_LEN 500
static char* prepare_description(CENTRIMO_OPTIONS_T* options) {
  char *desc;
  int i, shift, found;
  if (options->desc_file) {
    FILE *fp;
    size_t loaded;
    desc = mm_malloc(sizeof(char) * (MAX_JOB_DESC_LEN + 1));
    fp = fopen(options->desc_file, "r");
    if (fp == NULL) {
      fprintf(stderr, "Warning: Could not read job description file (%s).\n", 
          options->desc_file);
      return NULL;
    }
    loaded = fread(desc, sizeof(char), MAX_JOB_DESC_LEN, fp);
    fclose(fp);
    desc[loaded] = '\0'; // null terminate
  } else if (options->description) {
    // duplicate the command-line option so we can edit it
    desc = strdup(options->description);
  } else {
    return NULL;
  }
  // convert different new-line styles into line-feed
  shift = 0;
  for (i = 0; desc[i] != '\0'; i++) {
    if (desc[i] == '\r') {
      desc[i-shift] = '\n';
      if (desc[i+1] == '\n') {
        i++;
        shift++;
      }
    } else if (shift > 0) {
      desc[i-shift] = desc[i];
    }
  }
  desc[i-shift] = '\0';
  // remove leading whitespace
  shift = 0;
  for (i = 0; desc[i] != '\0' && isspace(desc[i]); i++) {
    shift++;
  }
  // merge 3 or more new lines into two
  found = 0;
  for (; desc[i] != '\0'; i++) {
    if (desc[i] != '\n') found = 0;
    else found++;
    if (found > 2) {
      shift++;
      continue;
    }
    desc[i-shift] = desc[i];
  }
  desc[i-shift] = '\0';
  // remove trailing whitespace
  for (i = i - shift - 1; i >= 0 && isspace(desc[i]); i--) desc[i] = '\0';
  // resize memory allocation
  desc = mm_realloc(desc, sizeof(char) * (i + 1));
  // return description
  return desc;
}

/*************************************************************************
 * Free a motif database
 *************************************************************************/
static void free_db(MOTIF_DB_T* db) {
  free(db->source);
  arraylst_destroy(destroy_motif, db->motifs);
  memset(db, 0, sizeof(MOTIF_DB_T));
  free(db);
}

/*************************************************************************
 * Make a PSSM for centrimo
 *************************************************************************/
static PSSM_T* make_pssm(ARRAY_T* bg_freqs, MOTIF_T *motif) {
  PSSM_T *pssm;

  // Build PSSM for motif and tables for p-value calculation.
  // p-values are not used in centrimo, only scores
  pssm = build_motif_pssm(
      motif, 
      bg_freqs, 
      bg_freqs, //p-value background
      NULL, // prior distribution 
      ALPHA, //non-motif specific scale factor
      PSSM_RANGE, 
      0,    // no GC bins
      FALSE // make log-likelihood pssm
      );
  return pssm;
}

/*************************************************************************
 * Entry point for centrimo
 *************************************************************************/
int main(int argc, char *argv[]) {
  CENTRIMO_OPTIONS_T options;
  SEQ_SITES_T seq_sites;
  SITE_COUNTS_T counts;
  int seqN, motifN, seqlen, db_i, motif_i, i;
  double log_pvalue_thresh;
  SEQ_T** sequences = NULL;
  ARRAY_T* bg_freqs = NULL;
  ARRAYLST_T *stats_list;
  MOTIF_DB_T **dbs, *db;
  MREAD_T *mread;
  MOTIF_STATS_T *stats;
  MOTIF_T *motif, *rev_motif;
  PSSM_T *pos_pssm, *rev_pssm;
  char *sites_path, *desc;
  FILE *sites_file;
  HTMLWR_T *html;
  JSONWR_T *json;

  // COMMAND LINE PROCESSING
  process_command_line(argc, argv, &options);

  // load the sequences
  read_sequences(options.alphabet, options.seq_source, &sequences, &seqN);
  seqlen = (seqN ? get_seq_length(sequences[0]) : 0);
  // calculate a sequence background (unless other background is given)
  if (!options.bg_source) {
    bg_freqs = calc_bg_from_fastas(options.alphabet, seqN, sequences);
  }

  // load the motifs
  motifN = 0;
  dbs = mm_malloc(sizeof(MOTIF_DB_T*) * arraylst_size(options.motif_sources));
  for (i = 0; i < arraylst_size(options.motif_sources); i++) {
    char* db_source;
    db_source = (char*)arraylst_get(i, options.motif_sources);
    dbs[i] = read_motifs(i, db_source, options.bg_source, &bg_freqs, 
        options.pseudocount, options.selected_motifs, options.alphabet);
    motifN += arraylst_size(dbs[i]->motifs);
  }
  log_pvalue_thresh = log(options.evalue_thresh) - log(motifN);
  // Setup some things for double strand scanning
  if (options.scan_both_strands == TRUE) {
    // Set up hash tables for computing reverse complement
    setup_hash_alph(DNAB);
    setalph(0);
    // Correct background by averaging on freq. for both strands.
    average_freq_with_complement(options.alphabet, bg_freqs);
    normalize_subarray(0, alph_size(options.alphabet, ALPH_SIZE), 0.0, bg_freqs);
    calc_ambigs(options.alphabet, FALSE, bg_freqs);
  }
  // Create output directory
  if (create_output_directory(options.output_dirname, options.allow_clobber, 
        (verbosity >= NORMAL_VERBOSE))) {
    die("Couldn't create output directory %s.\n", options.output_dirname);
  }
  // open output files
  sites_path = make_path_to_file(options.output_dirname, SITES_FILENAME);
  sites_file = fopen(sites_path, "w");
  free(sites_path);
  // setup html monolith writer
  json = NULL;
  if ((html = htmlwr_create(get_meme_etc_dir(), TEMPLATE_FILENAME))) {
    htmlwr_set_dest_name(html, options.output_dirname, HTML_FILENAME);
    htmlwr_replace(html, "centrimo_data.js", "data");
    json = htmlwr_output(html);
    if (json == NULL) die("Template does not contain data section.\n");
  } else {
    DEBUG_MSG(QUIET_VERBOSE, "Failed to open html template file.\n");
  }
  if (json) {
    // output some top level variables
    jsonwr_str_prop(json, "version", VERSION);
    jsonwr_str_prop(json, "revision", REVISION);
    jsonwr_str_prop(json, "release", ARCHIVE_DATE);
    jsonwr_str_array_prop(json, "cmd", argv, argc);
    jsonwr_property(json, "options");
    jsonwr_start_object_value(json);
    jsonwr_dbl_prop(json, "motif-pseudo", options.pseudocount);
    jsonwr_dbl_prop(json, "score", options.score_thresh);
    jsonwr_dbl_prop(json, "ethresh", options.evalue_thresh);
    jsonwr_lng_prop(json, "maxbin", options.max_window+1);
    jsonwr_bool_prop(json, "norc", !options.scan_both_strands);
    jsonwr_bool_prop(json, "noflip", options.no_flip);
    jsonwr_end_object_value(json);
    // output the description
    desc = prepare_description(&options);
    if (desc) {
      jsonwr_str_prop(json, "job_description", desc);
      free(desc);
    }
    // output size metrics
    jsonwr_lng_prop(json, "seqlen", seqlen);
    jsonwr_lng_prop(json, "tested", motifN);
    // output the fasta db
    jsonwr_property(json, "sequence_db");
    jsonwr_start_object_value(json);
    jsonwr_str_prop(json, "source", options.seq_source);
    jsonwr_lng_prop(json, "count", seqN);
    jsonwr_end_object_value(json);
    // output the motif dbs
    jsonwr_property(json, "motif_dbs");
    jsonwr_start_array_value(json);
    for (db_i = 0; db_i < arraylst_size(options.motif_sources); db_i++) {
      db = dbs[db_i];
      jsonwr_start_object_value(json);
      jsonwr_str_prop(json, "source", db->source);
      jsonwr_lng_prop(json, "count", arraylst_size(db->motifs));
      jsonwr_end_object_value(json);
    }
    jsonwr_end_array_value(json);
    // start the motif array
    jsonwr_property(json, "motifs");
    jsonwr_start_array_value(json);
  }
  /**************************************************************
   * Tally the positions of the best sites for each of the 
   * selected motifs.
   **************************************************************/
  // prepare the sequence sites
  memset(&seq_sites, 0, sizeof(SEQ_SITES_T));
  // prepare the site counts
  counts.allocated = ((2 * seqlen) - 1);
  counts.sites = mm_malloc(sizeof(double) * counts.allocated);
  // prepare the motifs stats list
  stats_list = arraylst_create();
  // prepare the other vars
  motif = NULL; pos_pssm = NULL; rev_motif = NULL; rev_pssm = NULL;
  for (db_i = 0; db_i < arraylst_size(options.motif_sources); db_i++) {
    db = dbs[db_i];
    for (motif_i = 0; motif_i < arraylst_size(db->motifs); motif_i++) {
      motif = (MOTIF_T *) arraylst_get(motif_i, db->motifs);
      DEBUG_FMT(NORMAL_VERBOSE, "Using motif %s of width %d.\n",  
          get_motif_id(motif), get_motif_length(motif));
      // reset the counts
      for (i = 0; i < counts.allocated; i++) counts.sites[i] = 0;
      counts.total_sites = 0;
      // create the pssm 
      pos_pssm = make_pssm(bg_freqs, motif);
      // If required, do the same for the reverse complement motif.
      if (options.scan_both_strands) {
        rev_motif = dup_rc_motif(motif);
        rev_pssm = make_pssm(bg_freqs, rev_motif);
      }
      // scan the sequences
      for (i = 0; i < seqN; i++)
        score_sequence(&options, sequences[i], pos_pssm, rev_pssm, 
            &seq_sites, &counts);
      // DEBUG check that the sum of the sites is close to the site count
      double sum_check = 0, sum_diff;
      for (i = 0; i < counts.allocated; i++) sum_check += counts.sites[i];
      sum_diff = counts.total_sites - sum_check;
      if (sum_diff < 0) sum_diff = -sum_diff;
      if (sum_diff > 0.1) {
        fprintf(stderr, "Warning: site counts don't sum to accurate value! "
            "%g != %ld", sum_check, counts.total_sites);
      }
      // output the plain text site counts
      output_site_counts(sites_file, seqlen, db, motif, &counts);
      // compute the best central window
      stats = compute_stats(options.max_window, seqlen, db, motif, &counts);
      // check if it passes the threshold
      if (json && stats->log_adj_pvalue <= log_pvalue_thresh) {
        output_motif_json(json, stats, &counts);
        arraylst_add(stats, stats_list);
      } else {
        free(stats);
      }
      // Free memory associated with this motif.
      free_pssm(pos_pssm);
      free_pssm(rev_pssm);
      destroy_motif(rev_motif);
    }
  }
  if (json) jsonwr_end_array_value(json);
  // finish writing sites
  fclose(sites_file);
  // finish writing html file
  if (html) {
    if (htmlwr_output(html) != NULL) {
      die("Found another JSON replacement!\n");
    }
    htmlwr_destroy(html);
  }
  // write text file
  output_centrimo_text(&options, motifN, stats_list);
  // Clean up.
  for (i = 0; i < seqN; ++i) {
    free_seq(sequences[i]); 
  }
  free(sequences);
  for (i = 0; i < arraylst_size(options.motif_sources); i++) {
    free_db(dbs[i]);
  }
  free(dbs);
  free_array(bg_freqs);
  free(counts.sites);
  free(seq_sites.sites);
  arraylst_destroy(free, stats_list);
  cleanup_options(&options);
  return 0;

}
