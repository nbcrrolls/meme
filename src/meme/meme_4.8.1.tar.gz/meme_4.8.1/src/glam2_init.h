#ifndef GLAM2_INIT_H
#define GLAM2_INIT_H

#include "glam2_glam2.h"

void init(data *d);

#endif
