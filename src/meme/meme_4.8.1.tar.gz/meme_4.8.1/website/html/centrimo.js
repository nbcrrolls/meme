var vis_ids = [];

function $(id) {
  return document.getElementById(id);
}

function on_page_show() {
  pasted_sequences_enable($('use_pasted').checked);
  upload_secondaries_enable($('motif_db').value == 'upload');
}

function on_form_submit() {
  return check();
}

function on_form_reset() {
  return true;
}

function on_ch_db() {
  upload_secondaries_enable($('motif_db').value == 'upload');
}

function upload_secondaries_enable(enable) {
  $('db_upload_div').style.display = (enable ? 'block' : 'none');
}

function pasted_sequences_enable(enable) {
  $('sequences').disabled = enable;
  $('pasted_sequences').style.display = (enable ? 'block' : 'none');
}

function check() {
  if (!$('use_pasted').checked) {
    if ($('sequences').value == '') {
      alert("Please input a file of FASTA formatted sequences.\n");
      return false;
    }
  } else {
    if ($('pasted_sequences').value == '') {
      alert("Please input FASTA formatted sequences.\n");
      return false;
    }
  }
  if ($('motif_db').value == 'upload') {
    if ($('db_upload').value == '') {
      alert("Please input a secondary motif file.\n");
      return false;
    }
  }
  var email = $('email').value;
  var email_confirm = $('email_confirm').value;
  if (!email.indexOf("@")) {
    alert("Please input an email to send the job details to.\n");
    return false;
  }
  if (email != email_confirm) {
    alert("The confirmation email does not match. Please check the email entered.\n");
    return false;
  }
  return true;
}

//
// toggle
//
// Generic toggle visibility of a previously hidden element.
//
function show_toggle(id) {
  var vis = vis_ids[id];
  if (vis) {
    $(id).style.display = 'none';
    delete vis_ids[id];
  } else {
    $(id).style.display = 'block';
    vis_ids[id] = true;
  }
}

//
// show_hide
//
// Generic show/hide function for making toggleable sections.
//
function show_hide(show_id, hide_id) {
  if (hide_id != '') $(hide_id).style.display = 'none';
  if (show_id != '') $(show_id).style.display = 'block';
}
